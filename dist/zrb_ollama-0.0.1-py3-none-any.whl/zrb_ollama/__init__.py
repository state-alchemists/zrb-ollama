from .builtin import install
assert install

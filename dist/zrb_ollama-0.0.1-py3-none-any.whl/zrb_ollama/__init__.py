from .builtin import hello
assert hello

echo "Publish"
flit publish --repository {{input.zrb_ollama_repo}}

echo "Install packages"
pip install -r requirements.txt


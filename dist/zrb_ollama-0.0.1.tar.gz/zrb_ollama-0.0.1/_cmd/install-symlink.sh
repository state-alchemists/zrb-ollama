echo "Install symlink"
flit install --symlink
